<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="author" content="">

    <title>Website Blog</title>

    
    

    <?php echo notifyCss(); ?>

    <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/logins/login-9/assets/css/login-9.css">

    
    <link rel="stylesheet" href="<?php echo e(url('vendor/ladda/ladda-themeless.min.css')); ?>">

    
    

    <!-- Custom fonts for this template -->
    <link href="<?php echo e(url('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('css/sb-admin-2.min.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(url('vendor/select2/select2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/select2-atlantis.css')); ?>">

    <!-- Custom styles for this page -->
    <link href="<?php echo e(url('vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('style'); ?>
    

</head>

<body id="page-top">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'notify::components.notify','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('notify::notify'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        
        <?php echo $__env->make('components.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php if (isset($component)) { $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0 = $component; } ?>
<?php $component = App\View\Components\NavBar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\NavBar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0)): ?>
<?php $component = $__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0; ?>
<?php unset($__componentOriginal565ac802a352a92b1930760028d7b31c15a31dd0); ?>
<?php endif; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-4 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
                    <div class="" style="height: 35px"></div>

                    <?php echo $__env->yieldContent('content'); ?>

                    <?php echo $__env->yieldContent('modal'); ?>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php if (isset($component)) { $__componentOriginalbd6e30a1c33159fd5abed1a7e96ab0af16ca81b0 = $component; } ?>
<?php $component = App\View\Components\LogoutAlert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('logout-alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\LogoutAlert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd6e30a1c33159fd5abed1a7e96ab0af16ca81b0)): ?>
<?php $component = $__componentOriginalbd6e30a1c33159fd5abed1a7e96ab0af16ca81b0; ?>
<?php unset($__componentOriginalbd6e30a1c33159fd5abed1a7e96ab0af16ca81b0); ?>
<?php endif; ?>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(url('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(url('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(url('js/sb-admin-2.min.js')); ?>"></script>

    
    <script src="<?php echo e(url('vendor/ladda/spin.min.js')); ?>"></script>
    <script src="<?php echo e(url('vendor/ladda/ladda.min.js')); ?>"></script>
    <script src="<?php echo e(url('vendor/ladda/ladda.jquery.min.js')); ?>"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(url('vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(url('js/demo/datatables-demo.js')); ?>"></script>

    
    <script src="<?php echo e(url('vendor/bootstrap-5-toast-snackbar/src/toast.js')); ?>"></script>

    
    <script src="<?php echo e(url('js/mySetup.js')); ?>"></script>

    
    <script src="<?php echo e(url('vendor/select2/select2.min.js')); ?>"></script>

    
    

    <!-- Tambahkan JS SweetAlert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function() {
            // Mendapatkan URL saat ini
            var path = window.location.pathname;

            // Menambahkan kelas 'active' pada elemen nav-item yang sesuai
            $(".nav-item a.nav-link").each(function() {
                var href = $(this).attr('href');
                if (path === href) {
                    $(this).closest(".nav-item").addClass("active");
                    if ($(this).hasClass('collapsed')) {
                        $(this).attr("aria-expanded", "true");
                        $(this).closest(".collapse").addClass("show");
                        $(this).removeClass('collapsed');
                    }
                }
            });

            // Menambahkan kelas 'active' dan 'show' pada item collapse jika salah satu item di dalamnya aktif
            $(".collapse-item").each(function() {
                var href = $(this).attr('href');
                if (path === href) {
                    $(this).closest(".collapse").addClass("show");
                    $(this).closest(".nav-item").addClass("active").find(".nav-link").attr("aria-expanded",
                            "true")
                        .removeClass('collapsed');
                    $(this).addClass("active");
                }
            });
        });
    </script>



    
    
    <?php echo notifyJs(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\usaha-bersama-server-side\resources\views/layouts/app.blade.php ENDPATH**/ ?>